// ================ محاكاة قاعدة البيانات ================
const database = {
    users: [
        { id: 1, username: "student1", password: "pass123", role: "student", full_name: "حسام حسن خليل حسن", email: "hossam@university.edu", phone: "01234567891", avatar: "https://randomuser.me/api/portraits/men/22.jpg" },
        { id: 2, username: "student2", password: "pass123", role: "student", full_name: "عبدالرحمن محمود الشربيني", email: "abdelrahman@university.edu", phone: "01234567892", avatar: "https://randomuser.me/api/portraits/men/32.jpg" },
        { id: 3, username: "student3", password: "pass123", role: "student", full_name: "عمر عيد حسن علي رضوان", email: "omar@university.edu", phone: "01234567893", avatar: "https://randomuser.me/api/portraits/men/42.jpg" },
        { id: 4, username: "instructor1", password: "pass123", role: "instructor", full_name: "د. أحمد محمد عبدالرحمن", email: "ahmed@university.edu", phone: "01234567894", avatar: "https://randomuser.me/api/portraits/men/41.jpg" },
        { id: 5, username: "instructor2", password: "pass123", role: "instructor", full_name: "د. محمود السيد إبراهيم", email: "mahmoud@university.edu", phone: "01234567895", avatar: "https://randomuser.me/api/portraits/men/51.jpg" },
        { id: 6, username: "parent1", password: "pass123", role: "parent", full_name: "السيد خليل حسن", email: "khalil@university.edu", phone: "01234567896", avatar: "https://randomuser.me/api/portraits/men/61.jpg" }
    ],
    students: [
        { id: 1, user_id: 1, student_id: "202010001", major: "علوم الحاسوب", academic_year: "السنة الثالثة", gpa: 3.75, attendance: 94 },
        { id: 2, user_id: 2, student_id: "202010002", major: "هندسة البرمجيات", academic_year: "السنة الثالثة", gpa: 3.92, attendance: 97 },
        { id: 3, user_id: 3, student_id: "202010003", major: "الشبكات والأمن السيبراني", academic_year: "السنة الثانية", gpa: 3.45, attendance: 89 }
    ],
    instructors: [
        { id: 1, user_id: 4, department: "علوم الحاسوب", title: "أستاذ مساعد" },
        { id: 2, user_id: 5, department: "هندسة البرمجيات", title: "أستاذ" }
    ],
    parents: [
        { id: 1, user_id: 6, student_id: 1, relation: "والد" }
    ],
    courses: [
        { id: 1, course_code: "CS101", course_name: "دراسة جدوى اقتصادية", instructor_id: 1, credit_hours: 3 },
        { id: 2, course_code: "CS102", course_name: "إدارة المؤسسات المالية", instructor_id: 1, credit_hours: 3 },
        { id: 3, course_code: "CS103", course_name: "تطبيقات الحاسب", instructor_id: 2, credit_hours: 4 },
        { id: 4, course_code: "CS104", course_name: "نظم المعلومات المحاسبية", instructor_id: 2, credit_hours: 3 },
        { id: 5, course_code: "CS105", course_name: "دراسات محاسبية باللغة الانجليزية", instructor_id: 1, credit_hours: 2 }
    ],
    enrollments: [
        { id: 1, student_id: 1, course_id: 1, enrollment_date: "2023-09-01" },
        { id: 2, student_id: 1, course_id: 2, enrollment_date: "2023-09-01" },
        { id: 3, student_id: 1, course_id: 3, enrollment_date: "2023-09-01" },
        { id: 4, student_id: 1, course_id: 4, enrollment_date: "2023-09-01" },
        { id: 5, student_id: 1, course_id: 5, enrollment_date: "2023-09-01" }
    ],
    evaluations: [
        { id: 1, student_id: 1, course_id: 1, evaluation_type: "امتحان منتصف الفصل", score: 45, max_score: 50, weight: 30, date: "2023-10-15", notes: "أداء ممتاز" },
        { id: 2, student_id: 1, course_id: 1, evaluation_type: "واجب عملي", score: 18, max_score: 20, weight: 10, date: "2023-10-20", notes: "جيد جداً" },
        { id: 3, student_id: 1, course_id: 2, evaluation_type: "امتحان منتصف الفصل", score: 42, max_score: 50, weight: 30, date: "2023-10-16", notes: "جيد" },
        { id: 4, student_id: 1, course_id: 2, evaluation_type: "مشروع عملي", score: 28, max_score: 30, weight: 20, date: "2023-10-22", notes: "ممتاز" },
        { id: 5, student_id: 1, course_id: 3, evaluation_type: "اختبار قصير", score: 9, max_score: 10, weight: 5, date: "2023-10-18", notes: "جيد" },
        { id: 6, student_id: 1, course_id: 3, evaluation_type: "واجب عملي", score: 19, max_score: 20, weight: 10, date: "2023-10-25", notes: "ممتاز" },
        { id: 7, student_id: 1, course_id: 4, evaluation_type: "امتحان منتصف الفصل", score: 48, max_score: 50, weight: 30, date: "2023-10-17", notes: "ممتاز" },
        { id: 8, student_id: 1, course_id: 5, evaluation_type: "اختبار قصير", score: 8.5, max_score: 10, weight: 5, date: "2023-10-19", notes: "جيد جداً" }
    ]
};

// ================ المتغيرات العامة ================
let currentUser = null;
let currentRole = null;
let currentStudent = null;
let currentInstructor = null;
let currentParent = null;
let evaluationsData = [];

// ================ عناصر DOM ================
const loginPage = document.getElementById('loginPage');
const navbar = document.getElementById('navbar');
const dashboardContent = document.getElementById('dashboardContent');
const accountContent = document.getElementById('accountContent');
const roleOptions = document.querySelectorAll('.role-option');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const loginBtn = document.getElementById('loginBtn');
const errorMessage = document.getElementById('errorMessage');
const userDropdown = document.getElementById('userDropdown');
const dropdownMenu = document.getElementById('dropdownMenu');
const logoutBtn = document.getElementById('logoutBtn');
const navLinks = document.querySelectorAll('.nav-link');
const welcomeUserName = document.getElementById('welcomeUserName');
const welcomeMessage = document.getElementById('welcomeMessage');
const pendingEvaluations = document.getElementById('pendingEvaluations');
const summaryGrid = document.getElementById('summaryGrid');
const studentDashboard = document.getElementById('studentDashboard');
const studentName = document.getElementById('studentName');
const studentAvatar = document.getElementById('studentAvatar');
const studentFullName = document.getElementById('studentFullName');
const studentId = document.getElementById('studentId');
const studentMajor = document.getElementById('studentMajor');
const studentLevel = document.getElementById('studentLevel');
const studentGPA = document.getElementById('studentGPA');
const studentAttendance = document.getElementById('studentAttendance');
const studentCourses = document.getElementById('studentCourses');
const studentLevelStatus = document.getElementById('studentLevelStatus');
const evaluationsBody = document.getElementById('evaluationsBody');
const searchInput = document.getElementById('searchInput');
const courseFilter = document.getElementById('courseFilter');
const typeFilter = document.getElementById('typeFilter');
const profilePicture = document.getElementById('profilePicture');
const profilePictureInput = document.getElementById('profilePictureInput');
const accountForm = document.getElementById('accountForm');
const fullName = document.getElementById('fullName');
const email = document.getElementById('email');
const phone = document.getElementById('phone');
const major = document.getElementById('major');
const academicYear = document.getElementById('academicYear');
const currentPassword = document.getElementById('currentPassword');
const newPassword = document.getElementById('newPassword');
const confirmPassword = document.getElementById('confirmPassword');
const saveAccountBtn = document.getElementById('saveAccountBtn');
const userFullName = document.getElementById('userFullName');
const userRoleDisplay = document.getElementById('userRoleDisplay');
const userAvatar = document.getElementById('userAvatar');

// ================ الرسوم البيانية ================
let performanceChart = null;
let progressChart = null;

// ================ الأحداث ================
document.addEventListener('DOMContentLoaded', function() {
    // اختيار دور المستخدم
    roleOptions.forEach(option => {
        option.addEventListener('click', function() {
            roleOptions.forEach(opt => opt.classList.remove('selected'));
            this.classList.add('selected');
            currentRole = this.getAttribute('data-role');
        });
    });

    // تسجيل الدخول
    loginBtn.addEventListener('click', login);

    // القائمة المنسدلة للمستخدم
    userDropdown.addEventListener('click', function(e) {
        e.stopPropagation();
        dropdownMenu.classList.toggle('show');
    });

    // إغلاق القائمة المنسدلة عند النقر في أي مكان
    document.addEventListener('click', function() {
        dropdownMenu.classList.remove('show');
    });

    // منع إغلاق القائمة عند النقر عليها
    dropdownMenu.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // تسجيل الخروج
    logoutBtn.addEventListener('click', logout);

    // التنقل بين علامات التبويب
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const tab = this.getAttribute('data-tab');
            showTab(tab);
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // البحث والتصفية
    searchInput.addEventListener('input', filterEvaluations);
    courseFilter.addEventListener('change', filterEvaluations);
    typeFilter.addEventListener('change', filterEvaluations);

    // تغيير صورة الملف الشخصي
    profilePictureInput.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                profilePicture.src = e.target.result;
                if (currentUser) {
                    currentUser.avatar = e.target.result;
                    userAvatar.src = e.target.result;
                }
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    // حفظ إعدادات الحساب
    saveAccountBtn.addEventListener('click', saveAccountSettings);

    // فرز الجدول
    document.querySelectorAll('#evaluationsTable th[data-sort]').forEach(th => {
        th.addEventListener('click', function() {
            const sortBy = this.getAttribute('data-sort');
            sortEvaluations(sortBy);
        });
    });

    // تهيئة التاريخ الأخير
    const lastLogin = new Date();
    lastLogin.setDate(lastLogin.getDate() - 2);
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    const lastLoginStr = lastLogin.toLocaleDateString('ar-EG', options);
    document.getElementById('welcomeMessage').innerHTML = `آخر دخول لك كان ${lastLoginStr}. لديك <span id="pendingEvaluations">5</span> تقييمات جديدة تحتاج مراجعتها.`;
});

// ================ الدوال ================
function login() {
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    if (!username || !password || !currentRole) {
        showError('يرجى تعبئة جميع الحقول واختيار دور المستخدم');
        return;
    }

    // محاكاة عملية المصادقة
    const user = database.users.find(u => u.username === username && u.password === password && u.role === currentRole);

    if (user) {
        currentUser = user;
        hideLoginPage();
        setupUserDashboard();
    } else {
        showError('اسم المستخدم أو كلمة المرور غير صحيحة!');
    }
}

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    setTimeout(() => {
        errorMessage.style.display = 'none';
    }, 5000);
}

function hideLoginPage() {
    loginPage.style.display = 'none';
    navbar.style.display = 'flex';
    dashboardContent.style.display = 'block';
}

function setupUserDashboard() {
    // تحديث معلومات المستخدم في الشريط العلوي
    userFullName.textContent = currentUser.full_name;
    userAvatar.src = currentUser.avatar;

    // تحديث الدور
    if (currentUser.role === 'student') {
        userRoleDisplay.textContent = 'طالب';
        currentStudent = database.students.find(s => s.user_id === currentUser.id);
        studentDashboard.style.display = 'block';
        setupStudentDashboard();
    } else if (currentUser.role === 'instructor') {
        userRoleDisplay.textContent = 'أستاذ';
        currentInstructor = database.instructors.find(i => i.user_id === currentUser.id);
        studentDashboard.style.display = 'none';
    } else if (currentUser.role === 'parent') {
        userRoleDisplay.textContent = 'ولي أمر';
        currentParent = database.parents.find(p => p.user_id === currentUser.id);
        studentDashboard.style.display = 'none';
    }

    // تحديث رسالة الترحيب
    welcomeUserName.textContent = currentUser.full_name;

    // تحديث لوحة الإحصائيات
    updateSummaryGrid();

    // تحميل التقييمات
    loadEvaluations();

    // تهيئة الرسوم البيانية
    initCharts();
}

function setupStudentDashboard() {
    if (!currentStudent) return;

    // تحديث معلومات الطالب
    studentName.textContent = currentUser.full_name;
    studentFullName.textContent = currentUser.full_name;
    studentId.textContent = currentStudent.student_id;
    studentMajor.textContent = currentStudent.major;
    studentLevel.textContent = currentStudent.academic_year;
    studentGPA.textContent = currentStudent.gpa;
    studentAttendance.textContent = `${currentStudent.attendance}%`;
    studentCourses.textContent = database.enrollments.filter(e => e.student_id === currentStudent.id).length;
    studentLevelStatus.textContent = getLevelStatus(currentStudent.gpa);
    studentAvatar.src = currentUser.avatar;
}

function getLevelStatus(gpa) {
    if (gpa >= 3.5) return 'ممتاز';
    if (gpa >= 3.0) return 'جيد جداً';
    if (gpa >= 2.5) return 'جيد';
    return 'مقبول';
}

function updateSummaryGrid() {
    let html = '';

    if (currentUser.role === 'student') {
        const courses = database.enrollments.filter(e => e.student_id === currentStudent.id).length;
        const evaluations = database.evaluations.filter(e => e.student_id === currentStudent.id).length;
        const attendance = currentStudent.attendance;
        const gpa = currentStudent.gpa;

        html = `
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">المقررات المسجلة</div>
                    <div class="summary-value">${courses}</div>
                    <div class="summary-desc">الفصل الأول 2023/2024</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-clipboard-check"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">عدد التقييمات</div>
                    <div class="summary-value">${evaluations}</div>
                    <div class="summary-desc">تم تسليمها هذا الفصل</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-user-check"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">نسبة الحضور</div>
                    <div class="summary-value">${attendance}%</div>
                    <div class="summary-desc">حتى تاريخ اليوم</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">المعدل التراكمي</div>
                    <div class="summary-value">${gpa}</div>
                    <div class="summary-desc">${getLevelStatus(gpa)}</div>
                </div>
            </div>
        `;
    } else if (currentUser.role === 'instructor') {
        const courses = database.courses.filter(c => c.instructor_id === currentInstructor.id).length;
        const students = database.enrollments.filter(e => 
            database.courses.some(c => c.id === e.course_id && c.instructor_id === currentInstructor.id)
        ).length;
        const evaluations = database.evaluations.filter(e => 
            database.courses.some(c => c.id === e.course_id && c.instructor_id === currentInstructor.id)
        ).length;

        html = `
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">المقررات</div>
                    <div class="summary-value">${courses}</div>
                    <div class="summary-desc">هذا الفصل الدراسي</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">عدد الطلاب</div>
                    <div class="summary-value">${students}</div>
                    <div class="summary-desc">المسجلين في مقرراتك</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-clipboard-list"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">التقييمات</div>
                    <div class="summary-value">${evaluations}</div>
                    <div class="summary-desc">تم تسجيلها هذا الفصل</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-tasks"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">المهام المعلقة</div>
                    <div class="summary-value">12</div>
                    <div class="summary-desc">تحتاج مراجعتك</div>
                </div>
            </div>
        `;
    } else if (currentUser.role === 'parent') {
        const student = database.students.find(s => s.id === currentParent.student_id);
        const studentUser = database.users.find(u => u.id === student.user_id);
        const courses = database.enrollments.filter(e => e.student_id === student.id).length;
        const gpa = student.gpa;

        html = `
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">الطالب</div>
                    <div class="summary-value">${studentUser.full_name}</div>
                    <div class="summary-desc">${student.major}</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">المقررات</div>
                    <div class="summary-value">${courses}</div>
                    <div class="summary-desc">هذا الفصل الدراسي</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">المعدل التراكمي</div>
                    <div class="summary-value">${gpa}</div>
                    <div class="summary-desc">${getLevelStatus(gpa)}</div>
                </div>
            </div>
            <div class="summary-box">
                <div class="summary-icon">
                    <i class="fas fa-user-check"></i>
                </div>
                <div class="summary-content">
                    <div class="summary-title">نسبة الحضور</div>
                    <div class="summary-value">${student.attendance}%</div>
                    <div class="summary-desc">حتى تاريخ اليوم</div>
                </div>
            </div>
        `;
    }

    summaryGrid.innerHTML = html;
}

function loadEvaluations() {
    if (currentUser.role === 'student') {
        evaluationsData = database.evaluations.filter(e => e.student_id === currentStudent.id);
    } else if (currentUser.role === 'instructor') {
        // الحصول على المقررات التي يدرسها الأستاذ
        const instructorCourses = database.courses.filter(c => c.instructor_id === currentInstructor.id).map(c => c.id);
        evaluationsData = database.evaluations.filter(e => instructorCourses.includes(e.course_id));
    } else if (currentUser.role === 'parent') {
        const student = database.students.find(s => s.id === currentParent.student_id);
        evaluationsData = database.evaluations.filter(e => e.student_id === student.id);
    }

    renderEvaluations(evaluationsData);
}

function renderEvaluations(data) {
    let html = '';
    
    data.forEach(evalItem => {
        const course = database.courses.find(c => c.id === evalItem.course_id);
        const percentage = ((evalItem.score / evalItem.max_score) * 100).toFixed(1);
        
        html += `
            <tr>
                <td>${course.course_name}</td>
                <td>${evalItem.evaluation_type}</td>
                <td>${evalItem.score}/${evalItem.max_score}</td>
                <td>${evalItem.weight}%</td>
                <td>${percentage}%</td>
                <td>${formatDate(evalItem.date)}</td>
                <td><span class="status-badge status-${getStatusClass(percentage)}">${getStatusText(percentage)}</span></td>
            </tr>
        `;
    });
    
    evaluationsBody.innerHTML = html;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-EG');
}

function getStatusClass(percentage) {
    if (percentage >= 85) return 'excellent';
    if (percentage >= 75) return 'good';
    return 'average';
}

function getStatusText(percentage) {
    if (percentage >= 85) return 'ممتاز';
    if (percentage >= 75) return 'جيد';
    return 'متوسط';
}

function filterEvaluations() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    const courseFilterValue = courseFilter.value;
    const typeFilterValue = typeFilter.value;
    
    let filtered = evaluationsData;
    
    if (searchTerm) {
        filtered = filtered.filter(evalItem => {
            const course = database.courses.find(c => c.id === evalItem.course_id);
            return course.course_name.toLowerCase().includes(searchTerm) || 
                   evalItem.evaluation_type.toLowerCase().includes(searchTerm);
        });
    }
    
    if (courseFilterValue) {
        filtered = filtered.filter(evalItem => {
            const course = database.courses.find(c => c.id === evalItem.course_id);
            return course.course_name === courseFilterValue;
        });
    }
    
    if (typeFilterValue) {
        filtered = filtered.filter(evalItem => evalItem.evaluation_type === typeFilterValue);
    }
    
    renderEvaluations(filtered);
}

function sortEvaluations(sortBy) {
    const th = document.querySelector(`#evaluationsTable th[data-sort="${sortBy}"]`);
    const isAsc = !th.classList.contains('sorted-asc');
    
    // إزالة علامات الفرز من جميع الرؤوس
    document.querySelectorAll('#evaluationsTable th').forEach(header => {
        header.classList.remove('sorted-asc', 'sorted-desc');
    });
    
    // إضافة علامة الفرز للرأس الحالي
    th.classList.add(isAsc ? 'sorted-asc' : 'sorted-desc');
    
    evaluationsData.sort((a, b) => {
        let valueA, valueB;
        
        switch (sortBy) {
            case 'course':
                const courseA = database.courses.find(c => c.id === a.course_id).course_name;
                const courseB = database.courses.find(c => c.id === b.course_id).course_name;
                valueA = courseA;
                valueB = courseB;
                break;
            case 'type':
                valueA = a.evaluation_type;
                valueB = b.evaluation_type;
                break;
            case 'score':
                valueA = a.score / a.max_score;
                valueB = b.score / b.max_score;
                break;
            case 'weight':
                valueA = a.weight;
                valueB = b.weight;
                break;
            case 'percentage':
                valueA = (a.score / a.max_score) * 100;
                valueB = (b.score / b.max_score) * 100;
                break;
            case 'date':
                valueA = new Date(a.date);
                valueB = new Date(b.date);
                break;
            case 'status':
                valueA = (a.score / a.max_score) * 100;
                valueB = (b.score / b.max_score) * 100;
                break;
            default:
                return 0;
        }
        
        if (typeof valueA === 'string') {
            return isAsc ? valueA.localeCompare(valueB) : valueB.localeCompare(valueA);
        } else {
            return isAsc ? valueA - valueB : valueB - valueA;
        }
    });
    
    renderEvaluations(evaluationsData);
}

function initCharts() {
    // تدمير الرسوم البيانية الحالية إذا كانت موجودة
    if (performanceChart) performanceChart.destroy();
    if (progressChart) progressChart.destroy();
    
    // رسم بياني دائري للأداء
    const performanceCtx = document.getElementById('performanceChart').getContext('2d');
    performanceChart = new Chart(performanceCtx, {
        type: 'pie',
        data: {
            labels: ['ممتاز (85-100%)', 'جيد (75-84%)', 'متوسط (أقل من 75%)'],
            datasets: [{
                data: [6, 2, 0],
                backgroundColor: [
                    '#4CAF50',
                    '#2196F3',
                    '#FFC107'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'left',
                    rtl: true,
                    labels: {
                        font: {
                            family: 'Tajawal',
                            size: 14
                        }
                    }
                }
            }
        }
    });
    
    // رسم بياني خطي لتطور الأداء
    const progressCtx = document.getElementById('progressChart').getContext('2d');
    progressChart = new Chart(progressCtx, {
        type: 'line',
        data: {
            labels: ['الفصل الأول 2021', 'الفصل الثاني 2021', 'الفصل الأول 2022', 'الفصل الثاني 2022', 'الفصل الأول 2023'],
            datasets: [{
                label: 'المعدل التراكمي',
                data: [3.2, 3.4, 3.5, 3.6, 3.75],
                borderColor: '#1a56db',
                backgroundColor: 'rgba(26, 86, 219, 0.1)',
                borderWidth: 3,
                pointBackgroundColor: '#1a56db',
                pointRadius: 5,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    min: 2.0,
                    max: 4.0,
                    ticks: {
                        stepSize: 0.5
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        font: {
                            family: 'Tajawal',
                            size: 14
                        }
                    }
                }
            }
        }
    });
}

function showTab(tab) {
    dashboardContent.style.display = tab === 'dashboard' ? 'block' : 'none';
    accountContent.style.display = tab === 'account' ? 'block' : 'none';
}

function logout() {
    currentUser = null;
    currentRole = null;
    currentStudent = null;
    currentInstructor = null;
    currentParent = null;
    evaluationsData = [];
    
    // إعادة تعيين حقول تسجيل الدخول
    usernameInput.value = '';
    passwordInput.value = '';
    roleOptions.forEach(opt => opt.classList.remove('selected'));
    
    // إخفاء لوحة التحكم وإظهار صفحة تسجيل الدخول
    navbar.style.display = 'none';
    dashboardContent.style.display = 'none';
    accountContent.style.display = 'none';
    loginPage.style.display = 'flex';
}

function saveAccountSettings() {
    if (!currentUser) return;
    
    // التحقق من كلمة المرور الحالية إذا تم تغيير كلمة المرور
    if (newPassword.value || confirmPassword.value) {
        if (currentPassword.value !== currentUser.password) {
            alert('كلمة المرور الحالية غير صحيحة');
            return;
        }
        
        if (newPassword.value !== confirmPassword.value) {
            alert('كلمة المرور الجديدة وتأكيدها غير متطابقتين');
            return;
        }
        
        // تحديث كلمة المرور
        currentUser.password = newPassword.value;
        alert('تم تحديث كلمة المرور بنجاح');
        currentPassword.value = '';
        newPassword.value = '';
        confirmPassword.value = '';
    }
    
    // تحديث معلومات المستخدم
    currentUser.full_name = fullName.value;
    currentUser.email = email.value;
    currentUser.phone = phone.value;
    
    // تحديث معلومات الطالب إذا كان دور طالب
    if (currentUser.role === 'student' && currentStudent) {
        currentStudent.major = major.value;
        currentStudent.academic_year = academicYear.value;
    }
    
    // تحديث الواجهة
    userFullName.textContent = currentUser.full_name;
    if (currentUser.role === 'student') {
        studentFullName.textContent = currentUser.full_name;
        studentMajor.textContent = currentStudent.major;
        studentLevel.textContent = currentStudent.academic_year;
    }
    
    alert('تم حفظ التغييرات بنجاح');
}

// ================ تهيئة الرسوم البيانية عند تحميل الصفحة ================
window.onload = function() {
    // تهيئة أولية للرسوم البيانية (للعرض فقط)
    if (document.getElementById('performanceChart')) {
        initCharts();
    }
};