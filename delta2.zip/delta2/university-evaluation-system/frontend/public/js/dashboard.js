document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('token');
  if (!token) return alert('❌ Not logged in');

  const res = await fetch('/api/users/profile', {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  const data = await res.json();

  if (res.ok) {
    document.getElementById('welcome').textContent = `Welcome, ${data.role}`;
  } else {
    alert(data.message || '❌ Failed to load profile');
  }
});
