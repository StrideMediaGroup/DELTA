document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  const data = Object.fromEntries(form.entries());

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    const result = await res.json();

    if (res.ok) {
      localStorage.setItem('token', result.token);
      alert('✅ Login successful!');
      window.location.href = '/dashboard.html';
    } else {
      alert(result.message || '❌ Login failed');
    }
  } catch (err) {
    alert('❌ Server error. Check console.');
    console.error(err);
  }
});
