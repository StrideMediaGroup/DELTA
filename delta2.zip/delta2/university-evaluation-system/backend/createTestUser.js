const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');
const User = require('./models/User');

// تحميل إعدادات .env
dotenv.config();

// الاتصال بقاعدة البيانات
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(async () => {
  const hashedPassword = await bcrypt.hash('123456', 10);
  const admin = new User({
    username: 'admin',
    password: admin,
    role: 'admin'
  });

  await admin.save();
  console.log('✅ Admin user created: username=admin, password=123456');
  process.exit();
}).catch(err => {
  console.error('❌ DB connection failed:', err);
  process.exit(1);
});
