const jwt = require('jsonwebtoken');

// التحقق من صحة الرمز المميز (Token)
exports.authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader) {
    return res.status(401).json({ message: 'مطلوب مصادقة' });
  }
  
  const token = authHeader.split(' ')[1];
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ message: 'رمز غير صالح أو منتهي الصلاحية' });
  }
};

// التحقق من الصلاحيات بناءً على الدور
exports.authorize = (roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ 
        message: 'ليس لديك الصلاحية للقيام بهذه العملية' 
      });
    }
    next();
  };
};

// التحقق من أن المستخدم هو نفسه أو لديه صلاحيات
exports.verifyOwnership = (model) => {
  return async (req, res, next) => {
    try {
      const resource = await model.findById(req.params.id);
      
      if (!resource) {
        return res.status(404).json({ message: 'الموارد غير موجودة' });
      }
      
      // التحقق من أن المستخدم هو المالك أو لديه دور مدير
      if (resource.user.toString() !== req.user.userId && req.user.role !== 'مدير') {
        return res.status(403).json({ 
          message: 'ليس لديك الصلاحية للوصول إلى هذه البيانات' 
        });
      }
      
      next();
    } catch (error) {
      res.status(500).json({ 
        message: 'حدث خطأ أثناء التحقق من الملكية',
        error: error.message 
      });
    }
  };
};