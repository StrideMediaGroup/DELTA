const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// تسجيل مستخدم جديد
exports.register = async (req, res) => {
  try {
    const { name, email, password, role, studentId, department } = req.body;
    
    // التحقق من وجود المستخدم
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'البريد الإلكتروني مستخدم بالفعل' });
    }
    
    // التحقق من الرقم الجامعي للطلاب
    if (role === 'طالب') {
      const existingStudent = await User.findOne({ studentId });
      if (existingStudent) {
        return res.status(400).json({ message: 'الرقم الجامعي مستخدم بالفعل' });
      }
    }
    
    // تشفير كلمة المرور
    const hashedPassword = await bcrypt.hash(password, 12);
    
    // إنشاء مستخدم جديد
    const user = new User({
      name,
      email,
      password: hashedPassword,
      role,
      studentId: role === 'طالب' ? studentId : undefined,
      department
    });
    
    await user.save();
    
    res.status(201).json({ 
      message: 'تم إنشاء الحساب بنجاح',
      userId: user._id 
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'حدث خطأ أثناء إنشاء الحساب',
      error: error.message 
    });
  }
};

// تسجيل الدخول
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // البحث عن المستخدم
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: 'بيانات الدخول غير صحيحة' });
    }
    
    // التحقق من كلمة المرور
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'بيانات الدخول غير صحيحة' });
    }
    
    // تحديث وقت آخر دخول
    user.lastLogin = new Date();
    await user.save();
    
    // إنشاء رمز JWT
    const token = jwt.sign(
      { 
        userId: user._id, 
        email: user.email, 
        role: user.role,
        name: user.name
      }, 
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );
    
    res.status(200).json({ 
      token,
      userId: user._id,
      role: user.role,
      name: user.name
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'حدث خطأ أثناء تسجيل الدخول',
      error: error.message 
    });
  }
};

// الحصول على معلومات المستخدم
exports.getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }
    
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ 
      message: 'حدث خطأ أثناء جلب بيانات المستخدم',
      error: error.message 
    });
  }
};

// تحديث معلومات المستخدم
exports.updateUserProfile = async (req, res) => {
  try {
    const { name, department, profileImage } = req.body;
    const userId = req.user.userId;
    
    const user = await User.findByIdAndUpdate(
      userId,
      { name, department, profileImage },
      { new: true, runValidators: true }
    ).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }
    
    res.status(200).json({
      message: 'تم تحديث بيانات المستخدم بنجاح',
      user
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'حدث خطأ أثناء تحديث بيانات المستخدم',
      error: error.message 
    });
  }
};

// تغيير كلمة المرور
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.user.userId;
    
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }
    
    // التحقق من كلمة المرور الحالية
    const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: 'كلمة المرور الحالية غير صحيحة' });
    }
    
    // تحديث كلمة المرور الجديدة
    const hashedPassword = await bcrypt.hash(newPassword, 12);
    user.password = hashedPassword;
    await user.save();
    
    res.status(200).json({ message: 'تم تغيير كلمة المرور بنجاح' });
  } catch (error) {
    res.status(500).json({ 
      message: 'حدث خطأ أثناء تغيير كلمة المرور',
      error: error.message 
    });
  }
};