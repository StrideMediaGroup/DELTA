const Evaluation = require('../models/Evaluation');
const Student = require('../models/Student');
const Course = require('../models/Course');

exports.createEvaluation = async (req, res) => {
  try {
    const { studentId, courseId, score, comments } = req.body;
    
    const evaluation = new Evaluation({
      student: studentId,
      course: courseId,
      instructor: req.user.id,
      score,
      comments
    });
    
    await evaluation.save();
    
    // إضافة التقييم للطالب
    await Student.findByIdAndUpdate(studentId, {
      $push: { evaluations: evaluation._id }
    });
    
    // إضافة التقييم للمادة
    await Course.findByIdAndUpdate(courseId, {
      $push: { evaluations: evaluation._id }
    });
    
    res.status(201).json(evaluation);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateEvaluation = async (req, res) => {
  try {
    const { score, comments } = req.body;
    const evaluation = await Evaluation.findByIdAndUpdate(
      req.params.id,
      { score, comments },
      { new: true }
    );
    
    res.json(evaluation);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getStudentEvaluations = async (req, res) => {
  try {
    const evaluations = await Evaluation.find({ student: req.params.studentId })
      .populate('course', 'name code')
      .populate('instructor', 'user');
    
    res.json(evaluations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getCourseEvaluations = async (req, res) => {
  try {
    const evaluations = await Evaluation.find({ course: req.params.courseId })
      .populate('student', 'user')
      .populate('instructor', 'user');
    
    res.json(evaluations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getPerformanceStats = async (req, res) => {
  try {
    const studentId = req.params.studentId;
    const evaluations = await Evaluation.find({ student: studentId });
    
    const stats = {
      total: evaluations.length,
      average: evaluations.reduce((sum, eval) => sum + eval.score, 0) / evaluations.length,
      courses: {}
    };
    
    for (const eval of evaluations) {
      if (!stats.courses[eval.course]) {
        const course = await Course.findById(eval.course);
        stats.courses[eval.course] = {
          name: course.name,
          scores: [],
          average: 0
        };
      }
      stats.courses[eval.course].scores.push(eval.score);
    }
    
    for (const courseId in stats.courses) {
      const scores = stats.courses[courseId].scores;
      stats.courses[courseId].average = scores.reduce((sum, score) => sum + score, 0) / scores.length;
    }
    
    res.json(stats);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};