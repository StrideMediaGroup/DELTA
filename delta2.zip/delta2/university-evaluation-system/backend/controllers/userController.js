const User = require('../models/User');

// استخدم exports بدلاً من module.exports للدوال
exports.getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'خطأ في جلب بيانات المستخدم' });
  }
};

// تأكد أنك لا تصدر الكائن مرتين
// لا تستخدم module.exports هنا إذا كنت تستخدم exports