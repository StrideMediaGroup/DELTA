const mongoose = require('mongoose');
const User = require('./models/User');
const Order = require('./models/Order');

// الاتصال بقاعدة البيانات
mongoose.connect('mongodb://localhost:27017/dashboard', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

module.exports = {
    getUserCount: async () => {
        return await User.countDocuments();
    },
    getOrderCount: async () => {
        return await Order.countDocuments();
    },
    getTotalRevenue: async () => {
        const result = await Order.aggregate([
            { $group: { _id: null, total: { $sum: "$amount" } } }
        ]);
        return result[0]?.total || 0;
    },
    getActiveUsers: async () => {
        const threshold = new Date();
        threshold.setDate(threshold.getDate() - 7);
        return await User.countDocuments({ lastActive: { $gte: threshold } });
    }
};