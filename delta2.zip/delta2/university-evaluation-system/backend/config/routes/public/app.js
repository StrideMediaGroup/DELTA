const express = require('express');
const cors = require('cors');
const db = require('./db');
const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);

// Dashboard API
app.get('/api/dashboard', async (req, res) => {
    try {
        const dashboardData = {
            totalUsers: await db.getUserCount(),
            totalOrders: await db.getOrderCount(),
            totalRevenue: await db.getTotalRevenue(),
            activeUsers: await db.getActiveUsers(),
            revenueData: [12000, 19000, 15000, 18000, 22000, 25000] // مثال
        };
        res.json(dashboardData);
    } catch (error) {
        res.status(500).json({ message: 'خطأ في الخادم' });
    }
});

// تشغيل الخادم
app.listen(PORT, () => {
    console.log(`الخادم يعمل على المنفذ ${PORT}`);
});