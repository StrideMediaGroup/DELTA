// backend/server.js
require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const mongoose = require('mongoose');
const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = process.env.PORT || 5000; // تأكد أنه 5000

// Middleware
app.use(cors({
  origin: 'http://localhost:5000',
  credentials: true
}));
app.use(express.json());

// خدمة الملفات الثابتة
app.use(express.static(path.join(__dirname, '../frontend/public')));

// Routes
app.use('/api/auth', authRoutes);

// توجيه جميع الطلبات الأخرى إلى login.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/public/login.html'));
});

// الاتصال بقاعدة البيانات
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('تم الاتصال بقاعدة البيانات'))
.catch(err => console.error('خطأ في الاتصال:', err));

// تشغيل الخادم
app.listen(PORT, () => {
  console.log(`الخادم يعمل على: http://localhost:${PORT}`);
});