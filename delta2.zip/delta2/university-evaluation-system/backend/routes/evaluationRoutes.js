const express = require('express');
const router = express.Router();
const evaluationController = require('../controllers/evaluationController');
const authMiddleware = require('../middleware/authMiddleware');

router.post('/', authMiddleware, evaluationController.createEvaluation);
router.put('/:id', authMiddleware, evaluationController.updateEvaluation);
router.get('/student/:studentId', authMiddleware, evaluationController.getStudentEvaluations);
router.get('/course/:courseId', authMiddleware, evaluationController.getCourseEvaluations);
router.get('/performance/:studentId', authMiddleware, evaluationController.getPerformanceStats);

module.exports = router;