const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');

// تأكد من استدعاء الدوال بشكل صحيح
router.get('/test', (req, res) => {
  res.json({ message: 'مسار المستخدمين يعمل' });
})
// ... بقية المسارات

module.exports = router;