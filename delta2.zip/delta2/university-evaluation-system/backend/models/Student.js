const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  studentId: { type: String, required: true, unique: true },
  department: { type: String, required: true },
  parent: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  enrolledCourses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }],
  evaluations: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Evaluation' }]
});

module.exports = mongoose.model('Student', studentSchema);