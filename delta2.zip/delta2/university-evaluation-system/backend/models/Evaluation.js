const mongoose = require('mongoose');

const evaluationSchema = new mongoose.Schema({
  student: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  course: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Course', 
    required: true 
  },
  instructor: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  score: { 
    type: Number, 
    min: 0, 
    max: 100, 
    required: true 
  },
  maxScore: { 
    type: Number, 
    default: 100 
  },
  evaluationType: {
    type: String,
    enum: ['امتحان', 'واجب', 'مشروع', 'اختبار قصير', 'أنشطة'],
    default: 'امتحان'
  },
  weight: {
    type: Number,
    min: 0,
    max: 100,
    default: 100
  },
  comments: String,
  evaluationDate: { 
    type: Date, 
    default: Date.now 
  },
  createdAt: { 
    type: Date, 
    default: Date.now 
  }
});

module.exports = mongoose.model('Evaluation', evaluationSchema);