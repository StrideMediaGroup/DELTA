package delta_project59.com.university_evaluation_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityEvaluationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
