package delta_project59.com.university_evaluation_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversityEvaluationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversityEvaluationSystemApplication.class, args);
	}

}
